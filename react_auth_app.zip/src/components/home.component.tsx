import React, { useContext, useEffect } from 'react'
import { AuthContext } from '../context/auth.context'
import { AxiosContext } from '../context/axios.context';

export default function Home() {
  const { getAccessToken } = useContext(AuthContext);
  const axiosContext = useContext(AxiosContext);
  const fetchData = async() =>{
    const res = await axiosContext?.protectedAxios('/users');
    console.log('res', res?.data);
  }
  useEffect(()=>{
    fetchData();
  }, []);
  return (
    <div>Home</div>
  )
}
