export interface AuthState{
    accessToken: string;
    refreshToken: string;
    userId: string;
}

export interface AuthContextType{
    getAccessToken: Function;
    getRefreshToken: Function;
    setAuthState: Function;
    authState: AuthState;
}