import { ReactNode, createContext, useContext } from "react";
import { AxiosContextType } from "../types/axios";
import { AuthContext } from "./auth.context";
import axios from "axios";

const AxiosContext = createContext<AxiosContextType | null>(null);
const { Provider } = AxiosContext;

const AxiosProvider = (props: { children: ReactNode }) => {
    const authContext = useContext(AuthContext);

    const baseUrl = 'http://127.0.0.1:4000/api/';

    const protectedAxios = axios.create({
        baseURL: baseUrl
    });

    protectedAxios.interceptors.request.use(config => {
        if (!config.headers.Authorization) {
            config.headers.Authorization = `Bearer ${authContext?.getAccessToken()}`
        }
        return config;
    }, error => {
        return Promise.reject(error);
    });

    const publicAxios = axios.create({
        baseURL: baseUrl
    });

    return <Provider value={{ protectedAxios, publicAxios }}>
        {props.children}
    </Provider>
};

export { AxiosContext, AxiosProvider };