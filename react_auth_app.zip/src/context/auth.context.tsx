import { ReactNode, createContext, useState } from "react";
import { AuthContextType, AuthState } from "../types/auth";

const AuthContext = createContext<AuthContextType>({
    authState: {
        accessToken: '',
        refreshToken: '',
        userId: '',
    },
    getAccessToken: () => { },
    getRefreshToken: () => { },
    setAuthState: () => { }
});

const { Provider } = AuthContext;

const AuthProvider = (props: { children: ReactNode }) => {
    const authState = {
        accessToken: '',
        refreshToken: '',
        userId: '',
    };
    // const [authState, setAuthState] = useState<AuthState>({
    //     accessToken: '',
    //     refreshToken: '',
    //     userId: '',
    // });

    const setAuthState = async (input: { accessToken: string, refreshToken: string, userId: string }) => {
        localStorage.setItem('accessToken', input.accessToken);
        localStorage.setItem('refreshToken', input.refreshToken);
        localStorage.setItem('userId', input.userId);

    }

    const getAccessToken = () => localStorage.getItem('accessToken');
    const getRefreshToken = () => localStorage.getItem('refreshToken');

    return (
        <Provider value={{ authState, setAuthState, getAccessToken, getRefreshToken }}>
            {props.children}
        </Provider>
    );
}


export { AuthContext, AuthProvider };
